<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Addedroom extends Model
{
    protected $table ="addedroom";
}
