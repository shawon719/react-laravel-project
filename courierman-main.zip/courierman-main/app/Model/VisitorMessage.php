<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class VisitorMessage extends Model {

    protected $table = "visitor_messages";
    // table fields
    protected $guarded = [];
}
